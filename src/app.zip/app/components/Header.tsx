"use client";

import Image from "next/image";
import Link from "next/link";
import { Home, User, Building2, FileText, Ellipsis } from "lucide-react";
import React from "react";
import { usePathname } from "next/navigation";

const Header: React.FC = () => {
  const pathname = usePathname();

  const isActive = (path: string) => pathname === path;

  return (
    <>
      {/* Header: luôn hiển thị ở trên */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur border-b border-black/10 font-semibold">
        <div className="container-std flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Image
              src="/logo_phat_dat_bat_don_san.png"
              alt="Phát Đạt Bất Động Sản"
              height={50}
              width={50}
              unoptimized
            />
            <span className="sr-only">Phát Đạt Bất Động Sản</span>
          </div>

          {/* Menu ngang chỉ hiện trên desktop */}
          <nav className="hidden md:flex items-center gap-6 text-sm text-mute">
            <Link href="/" className="hover:text-black">
              Trang chủ
            </Link>
            <Link href="/nha-dat-ban" className="hover:text-black">
              Mua bán
            </Link>
            <Link href="/bai-viet" className="hover:text-black">
              Bài viết
            </Link>
            <Link href="#manage" className="hover:text-black">
              Quản lý
            </Link>
            <Link href="#resources" className="hover:text-black">
              Tài nguyên
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <button className="btn btn-dark text-sm">Đăng tin</button>
            <button className="btn btn-primary text-sm">Đăng nhập</button>
          </div>
        </div>
      </header>

      {/* Bottom navigation bar: chỉ hiện trên mobile */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
        <div className="flex justify-around items-center py-2 bg-white">
          {/* Mua bán */}
          <Link
            href="/nha-dat-ban"
            className={`flex flex-col items-center ${isActive("/nha-dat-ban")
                ? "text-[var(--color-accent)]"
                : "text-gray-500"
              }`}
          >
            <Building2 size={22} />
            <span className="text-xs">Mua bán</span>
          </Link>

          {/* Bài viết */}
          <Link
            href="/bai-viet"
            className={`flex flex-col items-center ${isActive("/bai-viet")
                ? "text-[var(--color-accent)]"
                : "text-gray-500"
              }`}
          >
            <FileText size={22} />
            <span className="text-xs">Bài viết</span>
          </Link>

          {/* Home: icon ở giữa, nổi bật */}
          <Link
            href="/"
            className={`flex flex-col items-center -mt-6 rounded-full p-4 shadow-lg ${isActive("/") ? "bg-[var(--color-accent)] text-white" : "bg-[var(--color-accent)] text-white"
              }`}
          >
            <Home size={24} />
          </Link>

          {/* Profile */}
          <Link
            href="/profile"
            className={`flex flex-col items-center ${isActive("/profile")
                ? "text-[var(--color-accent)]"
                : "text-gray-500"
              }`}
          >
            <User size={22} />
            <span className="text-xs">Profile</span>
          </Link>

          {/* More */}
          <Link
            href="/more"
            className={`flex flex-col items-center ${isActive("/more")
                ? "text-[var(--color-accent)]"
                : "text-gray-500"
              }`}
          >
            <Ellipsis size={22} />
            <span className="text-xs">More</span>
          </Link>
        </div>
      </nav>
    </>
  );
};

export default Header;
