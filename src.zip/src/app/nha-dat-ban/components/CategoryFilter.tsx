"use client"
import { useState } from 'react';

export default function CategoryFilter() {
  const [activeCategory, setActiveCategory] = useState('Villa');

  const categories = [
    { name: 'House', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M3 10.5L12 3l9 7.5M4.5 9.75V21h15V9.75" /></svg> },
    { name: 'Hotel', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M3 21V8.5A2.5 2.5 0 0 1 5.5 6H18a3 3 0 0 1 3 3V21M3 11h18M7.5 11V7.5m4 3.5V7.5m4 3.5V7.5" /></svg> },
    { name: 'Villa', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2c3 0 9 7 9 12a9 9 0 0 1-18 0c0-5 6-12 9-12Zm0 6.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z" /></svg> },
    { name: 'Apartment', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" d="M4 21V6a2 2 0 0 1 2-2h5v17M11 6h7a2 2 0 0 1 2 2v13M7 9h2m-2 4h2m-2 4h2m6-8h2m-2 4h2m-2 4h2" /></svg> },
  ];

  return (
    <section className="w-full bg-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar md:flex-wrap p-2">
            {categories.map((category) => (
              <button
                key={category.name}
                onClick={() => setActiveCategory(category.name)}
                className={`inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 shadow-sm border-0 whitespace-nowrap ${activeCategory === category.name ? 'ring-1 ring-indigo-100 shadow-md text-gray-900' : ''}`}
              >
                {category.icon}
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}